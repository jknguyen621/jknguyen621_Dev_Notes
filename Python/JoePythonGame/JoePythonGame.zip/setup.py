from distutils.core import setup
import py2exe

setup(console=['JoeS_Python_GUI_Rev3.py'])